//
//  Detailviewcontroller .swift
//  ACT05_JonathanOsirisGonzalezIbarra
//
//  Created by Jonathan Gonzalez on 07/10/25.
//

