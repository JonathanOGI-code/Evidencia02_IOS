//
//  AddMovieView.swift
//  ACT08_AnimesApp
//
//  Created by Jonathan Gonzalez on 21/10/25.
//

import SwiftUI

struct AddMovieView: View {
    // Ahora esta vista recibe y modifica una lista de Animes
    @Binding var animes: [Anime]
    
    // Estados para los campos del nuevo anime
    @State private var titulo: String = ""
    @State private var capitulosText: String = ""    // Lo capturamos como String y luego lo convertimos a Int
    @State private var fechaEstreno: Date = Date()   // Por defecto hoy
    
    // Para poder cerrar la vista
    @Environment(\.dismiss) var dismiss

    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("Datos del anime")) {
                    TextField("Título del anime", text: $titulo)
                    
                    TextField("Número de capítulos", text: $capitulosText)
                        .keyboardType(.numberPad)
                    
                    DatePicker("Fecha de estreno",
                               selection: $fechaEstreno,
                               displayedComponents: .date)
                }
            }
            .navigationTitle("Agregar Anime")
            .toolbar {
                // Botón para cancelar
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancelar") {
                        dismiss()
                    }
                }
                // Botón para guardar
                ToolbarItem(placement: .confirmationAction) {
                    Button("Guardar") {
                        // Validamos que los capítulos sean un número
                        guard let capitulos = Int(capitulosText),
                              !titulo.isEmpty else {
                            // Si falla, simplemente no guardamos (podrías añadir validaciones después)
                            return
                        }
                        
                        let nuevoAnime = Anime(
                            titulo: titulo,
                            capitulos: capitulos,
                            fechaEstreno: fechaEstreno
                        )
                        
                        animes.append(nuevoAnime)  // Agregamos el anime a la lista
                        dismiss()                  // Cerramos la hoja
                    }
                }
            }
        }
    }
}

