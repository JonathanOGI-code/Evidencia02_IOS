//
//  AnimesAppApp.swift
//  ACT08_JonathanOsirisGonzalezIbarra
//
//  Created by Jonathan Gonzalez on 21/10/25.
//

import SwiftUI

@main
struct AnimesAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()   // Aquí empieza la vista de listado de animes
        }
    }
}

