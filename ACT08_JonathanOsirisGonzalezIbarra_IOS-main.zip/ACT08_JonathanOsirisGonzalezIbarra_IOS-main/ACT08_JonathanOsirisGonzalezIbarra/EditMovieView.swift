//
//  EditMovieView.swift
//  ACT08_AnimesApp
//
//  Created by Jonathan Gonzalez on 21/10/25.
//

import SwiftUI

struct EditMovieView: View {
    // Para cerrar la vista
    @Environment(\.dismiss) var dismiss
    
    // La vista principal nos dice qué hacer cuando se guarde
    var onSave: (Anime) -> Void
    
    // Estados locales (copia de los datos originales del anime)
    @State private var titulo: String
    @State private var capitulosText: String
    @State private var fechaEstreno: Date
    
    // Guardamos el id original para saber qué anime actualizar
    private var originalId: UUID

    // Inicializador personalizado para configurar nuestros estados locales
    init(anime: Anime, onSave: @escaping (Anime) -> Void) {
        self.originalId = anime.id
        self._titulo = State(initialValue: anime.titulo)
        self._capitulosText = State(initialValue: String(anime.capitulos))
        self._fechaEstreno = State(initialValue: anime.fechaEstreno)
        self.onSave = onSave
    }

    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("Editar datos del anime")) {
                    TextField("Título del anime", text: $titulo)
                    
                    TextField("Número de capítulos", text: $capitulosText)
                        .keyboardType(.numberPad)
                    
                    DatePicker("Fecha de estreno",
                               selection: $fechaEstreno,
                               displayedComponents: .date)
                }
            }
            .navigationTitle("Editar Anime")
            .toolbar {
                // Botón para cancelar
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancelar") {
                        dismiss() // Cierra la vista sin guardar cambios
                    }
                }
                // Botón para actualizar
                ToolbarItem(placement: .confirmationAction) {
                    Button("Actualizar") {
                        // Validamos los datos
                        guard let capitulos = Int(capitulosText),
                              !titulo.isEmpty else {
                            return
                        }
                        
                        // Creamos un nuevo Anime con los datos editados y el ID original
                        let updatedAnime = Anime(
                            id: originalId,
                            titulo: titulo,
                            capitulos: capitulos,
                            fechaEstreno: fechaEstreno
                        )
                        
                        // Llamamos a la función onSave que nos pasó la vista principal
                        onSave(updatedAnime)
                        
                        // Cerramos la vista
                        dismiss()
                    }
                }
            }
        }
    }
}

