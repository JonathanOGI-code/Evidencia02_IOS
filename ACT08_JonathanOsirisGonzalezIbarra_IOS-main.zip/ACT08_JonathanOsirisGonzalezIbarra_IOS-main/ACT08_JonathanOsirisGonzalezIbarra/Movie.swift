//
//  Anime.swift
//  ACT08_AnimesApp
//
//  Created by Jonathan Gonzalez on ??/??/25.
//

import Foundation

// Identifiable le dice a SwiftUI cómo diferenciar un anime de otro en una lista.
struct Anime: Identifiable {
    var id = UUID()              // Identificador único para cada anime
    var titulo: String           // Nombre del anime
    var capitulos: Int           // Número de capítulos o temporadas
    var fechaEstreno: Date       // Fecha de estreno
}

