//
//  ContentView.swift
//  ACT08_JonathanOsirisGonzalezIbarra
//
//  Created by Jonathan Gonzalez on 21/10/25.
//

import SwiftUI

struct ContentView: View {
    @State private var animes: [Anime] = [
        // Ejemplos (opcional)
        // Anime(titulo: "Naruto", capitulos: 220, fechaEstreno: Date()),
        // Anime(titulo: "One Piece", capitulos: 1000, fechaEstreno: Date())
    ]
    
    @State private var showingAddSheet = false
    @State private var animeToEdit: Anime?

    var body: some View {
        NavigationStack {
            List {
                ForEach($animes) { $anime in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(anime.titulo)
                                .font(.headline)

                            Text("Capítulos: \(anime.capitulos)")
                                .font(.subheadline)

                            Text("Estreno: \(anime.fechaEstreno.formatted(date: .abbreviated, time: .omitted))")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                    }
                    .contentShape(Rectangle())
                    .onTapGesture {
                        animeToEdit = anime
                    }
                }
                .onDelete(perform: deleteAnime)
            }
            .navigationTitle("Listado de Animes")
            .toolbar {
                Button(action: {
                    showingAddSheet = true
                }) {
                    Image(systemName: "plus")
                }
            }
            .sheet(isPresented: $showingAddSheet) {
                AddMovieView(animes: $animes)
            }
            .sheet(item: $animeToEdit) { anime in
                EditMovieView(anime: anime) { updatedAnime in
                    if let index = animes.firstIndex(where: { $0.id == updatedAnime.id }) {
                        animes[index] = updatedAnime
                    }
                }
            }
        }
    }
    
    private func deleteAnime(at offsets: IndexSet) {
        animes.remove(atOffsets: offsets)
    }
}

#Preview {
    ContentView()
}

