//
//  Movie.swift
//  ACT07_JonathanOsirisGonzalezIbarra
//
//  Created by Jonathan Gonzalez on 21/10/25.
//

import Foundation

// Identifiable le dice a SwiftUI cómo diferenciar una película de otra en una lista.
struct Movie: Identifiable {
    var id = UUID() // Un identificador único y automático para cada película.
    var title: String
    var watched: Bool
}
