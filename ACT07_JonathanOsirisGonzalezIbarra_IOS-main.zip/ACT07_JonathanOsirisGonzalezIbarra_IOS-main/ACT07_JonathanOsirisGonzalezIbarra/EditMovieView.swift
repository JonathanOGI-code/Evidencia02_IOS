//
//  EditMovieView.swift
//  ACT07_JonathanOsirisGonzalezIbarra
//
//  Created by Jonathan Gonzalez on 21/10/25.
//

import SwiftUI

struct EditMovieView: View {
    // Para cerrar la vista
    @Environment(\.dismiss) var dismiss
    
    // Esta es la función que llamaremos para guardar los cambios.
    // La vista principal (ContentView) nos dirá qué hacer cuando se guarde.
    var onSave: (Movie) -> Void
    
    // Estados locales y privados. Son una COPIA de los datos originales.
    // Los cambios aquí NO afectan a la lista principal hasta que guardemos.
    @State private var title: String
    @State private var watched: Bool
    
    // Guardamos el id original para saber qué película actualizar
    private var originalId: UUID

    // Creamos un inicializador personalizado para configurar nuestros estados locales
    init(movie: Movie, onSave: @escaping (Movie) -> Void) {
        self.originalId = movie.id
        self._title = State(initialValue: movie.title) // Así se inicializa un @State
        self._watched = State(initialValue: movie.watched)
        self.onSave = onSave
    }

    var body: some View {
        NavigationStack {
            Form {
                TextField("Nombre de la película", text: $title)
                Toggle("¿Ya la viste?", isOn: $watched)
            }
            .navigationTitle("Editar Película")
            .toolbar {
                // Botón para cancelar
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancelar") {
                        dismiss() // Simplemente cierra la vista, los cambios se pierden.
                    }
                }
                // Botón para actualizar
                ToolbarItem(placement: .confirmationAction) {
                    Button("Actualizar") {
                        // 1. Creamos un nuevo objeto Movie con los datos editados y el ID original.
                        let updatedMovie = Movie(id: originalId, title: title, watched: watched)
                        
                        // 2. Llamamos a la función onSave que nos pasó la vista principal.
                        onSave(updatedMovie)
                        
                        // 3. Cerramos la vista.
                        dismiss()
                    }
                }
            }
        }
    }
}
