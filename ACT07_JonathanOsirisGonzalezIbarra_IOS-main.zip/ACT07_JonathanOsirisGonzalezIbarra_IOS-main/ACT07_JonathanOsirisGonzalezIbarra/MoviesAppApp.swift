//
//  MoviesAppApp.swift
//  ACT07_JonathanOsirisGonzalezIbarra
//
//  Created by Jonathan Gonzalez on 21/10/25.
//

import SwiftUI

@main
struct MoviesAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
