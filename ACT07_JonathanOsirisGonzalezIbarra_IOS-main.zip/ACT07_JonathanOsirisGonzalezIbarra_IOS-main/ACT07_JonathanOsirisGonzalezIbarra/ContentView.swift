//
//  ContentView.swift
//  ACT07_JonathanOsirisGonzalezIbarra
//
//  Created by Jonathan Gonzalez on 21/10/25.
//

import SwiftUI

struct ContentView: View {
    @State private var movies: [Movie] = [
        Movie(title: "Inception", watched: true),
        Movie(title: "The Matrix", watched: true),
        Movie(title: "Dune", watched: false)
    ]
    
    // Estados para controlar qué vista modal mostramos
    @State private var showingAddSheet = false
    @State private var movieToEdit: Movie? // Si contiene una película, mostramos la hoja de edición

    var body: some View {
        NavigationStack {
            List {
                // Usamos ForEach para poder añadir gestos a cada fila
                ForEach($movies) { $movie in
                    HStack {
                        Text(movie.title)
                        Spacer()
                        if movie.watched {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundColor(.green)
                        }
                    }
                    .contentShape(Rectangle()) // Hace que toda la fila sea tocable
                    .onTapGesture {
                        // Cuando se toca una fila, guardamos la película para editarla
                        movieToEdit = movie
                    }
                }
            }
            .navigationTitle("Películas por Ver")
            .toolbar {
                Button(action: {
                    showingAddSheet = true
                }) {
                    Image(systemName: "plus")
                }
            }
            // Hoja para AGREGAR película
            .sheet(isPresented: $showingAddSheet) {
                AddMovieView(movies: $movies)
            }
            // Hoja para EDITAR película
            // Se muestra cuando movieToEdit NO es nulo
            .sheet(item: $movieToEdit) { movie in
                // Le pasamos la película y definimos la acción de onSave
                EditMovieView(movie: movie) { updatedMovie in
                    // Este es el código que se ejecuta cuando se presiona "Actualizar"
                    // 1. Buscamos el índice de la película original
                    if let index = movies.firstIndex(where: { $0.id == updatedMovie.id }) {
                        // 2. La reemplazamos en el arreglo con la versión actualizada
                        movies[index] = updatedMovie
                    }
                }
            }
        }
    }
}
