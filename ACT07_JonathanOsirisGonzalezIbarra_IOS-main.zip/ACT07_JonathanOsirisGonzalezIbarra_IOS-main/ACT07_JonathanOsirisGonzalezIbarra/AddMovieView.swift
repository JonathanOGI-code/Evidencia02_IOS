//
//  AddMovieView.swift
//  ACT07_JonathanOsirisGonzalezIbarra
//
//  Created by Jonathan Gonzalez on 21/10/25.
//

import SwiftUI

struct AddMovieView: View {
    // @Binding significa que esta vista NO es dueña de la lista de películas,
    // solo la está "tomando prestada" de la vista anterior para poder agregarle algo.
    @Binding var movies: [Movie]
    
    // @State para las propiedades de la nueva película que estamos creando.
    @State private var title: String = ""
    @State private var watched: Bool = false
    
    // Una forma de cerrar la vista actual de forma programática.
    @Environment(\.dismiss) var dismiss

    var body: some View {
        NavigationStack {
            // Form le da un estilo de formulario estándar de iOS.
            Form {
                TextField("Nombre de la película", text: $title)
                // Toggle es el interruptor de encendido/apagado.
                Toggle("¿Ya la viste?", isOn: $watched)
            }
            .navigationTitle("Agregar Película")
            .toolbar {
                // Botón para cancelar
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancelar") {
                        dismiss() // Cierra la vista sin hacer nada
                    }
                }
                // Botón para guardar
                ToolbarItem(placement: .confirmationAction) {
                    Button("Guardar") {
                        let newMovie = Movie(title: title, watched: watched)
                        movies.append(newMovie) // Agregamos la película a la lista original
                        dismiss() // Cerramos la vista
                    }
                }
            }
        }
    }
}
